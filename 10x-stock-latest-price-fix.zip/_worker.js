const YAHOO_HOSTS = [
  'https://query1.finance.yahoo.com/v8/finance/chart/',
  'https://query2.finance.yahoo.com/v8/finance/chart/'
];

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store, no-cache, must-revalidate, max-age=0',
      'pragma': 'no-cache',
      'expires': '0'
    }
  });
}

function normalizeSymbol(market, code) {
  const c = String(code || '').trim().toUpperCase().replace(/\.T$/i, '');
  if (!c || !/^[0-9A-Z.\-^=]+$/.test(c)) return null;
  if (market === 'japan') {
    if (!/^\d{4}[A-Z]?$/.test(c)) return null;
    return c + '.T';
  }
  if (market === 'usa') return c;
  return null;
}

async function fetchLatest(symbol) {
  let lastStatus = 0;
  for (const host of YAHOO_HOSTS) {
    try {
      const url = `${host}${encodeURIComponent(symbol)}?range=1d&interval=1m&includePrePost=false&events=div%2Csplits&_=${Date.now()}`;
      const r = await fetch(url, {
        headers: {
          'Accept': 'application/json,text/plain,*/*',
          'User-Agent': 'Mozilla/5.0'
        },
        cache: 'no-store',
        cf: { cacheTtl: 0, cacheEverything: false }
      });
      lastStatus = r.status;
      if (!r.ok) continue;

      const body = await r.json();
      const result = body?.chart?.result?.[0];
      const meta = result?.meta;
      if (!meta) continue;

      const closes = result?.indicators?.quote?.[0]?.close || [];
      let latestClose = null;
      for (let i = closes.length - 1; i >= 0; i--) {
        const v = Number(closes[i]);
        if (Number.isFinite(v)) { latestClose = v; break; }
      }

      const marketPrice = Number(meta.regularMarketPrice);
      const price = Number.isFinite(latestClose) ? latestClose :
                    Number.isFinite(marketPrice) ? marketPrice : null;
      if (price === null) continue;

      return { meta, price };
    } catch (_) {}
  }
  return { error: 'quote_unavailable', status: lastStatus || 502 };
}

async function stockLookup(request) {
  const url = new URL(request.url);
  const market = url.searchParams.get('market');
  const code = String(url.searchParams.get('code') || '').trim().toUpperCase().replace(/\.T$/i, '');
  const symbol = normalizeSymbol(market, code);
  if (!symbol) return json({ ok:false, error:'invalid_code' }, 400);

  const y = await fetchLatest(symbol);
  if (!y.meta) return json({ ok:false, error:y.error || 'not_found' }, y.status || 502);

  const meta = y.meta;
  const price = y.price;
  const prev = Number(meta.chartPreviousClose ?? meta.previousClose);
  const changePct = Number.isFinite(prev) && prev > 0 ? (price / prev - 1) * 100 : 0;

  return json({
    ok:true,
    market,
    code,
    symbol: meta.symbol || symbol,
    name: meta.longName || meta.shortName || meta.symbol || code,
    price,
    change_pct: Math.round(changePct * 100) / 100,
    currency: meta.currency || (market === 'japan' ? 'JPY' : 'USD'),
    exchange: meta.fullExchangeName || meta.exchangeName || '',
    time: meta.regularMarketTime || null,
    source:'yahoo-1m-latest'
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/stock') return stockLookup(request);
    return env.ASSETS.fetch(request);
  }
};
