const YAHOO_HOSTS = [
  'https://query1.finance.yahoo.com/v8/finance/chart/',
  'https://query2.finance.yahoo.com/v8/finance/chart/'
];

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store, max-age=0',
      ...extra,
    },
  });
}

function normalizeSymbol(market, code) {
  const c = String(code || '').trim().toUpperCase().replace(/\.T$/i, '');
  if (!c || !/^[0-9A-Z.\-^=]+$/.test(c)) return null;
  if (market === 'japan') {
    if (!/^\d{4}[A-Z]?$/.test(c)) return null;
    return c + '.T';
  }
  if (market === 'usa') return c;
  return null;
}

async function fetchYahoo(symbol) {
  let lastStatus = 0;
  for (const host of YAHOO_HOSTS) {
    try {
      const u = `${host}${encodeURIComponent(symbol)}?interval=1d&range=5d&events=div%2Csplits`;
      const r = await fetch(u, {
        headers: {
          'Accept': 'application/json,text/plain,*/*',
          'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
          'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1'
        },
        cache: 'no-store',
        cf: { cacheTtl: 0, cacheEverything: false },
      });
      lastStatus = r.status;
      if (!r.ok) continue;
      const body = await r.json();
      const result = body?.chart?.result?.[0];
      const meta = result?.meta;
      const price = Number(meta?.regularMarketPrice);
      if (meta && Number.isFinite(price)) return { meta, price };
    } catch (_) {}
  }
  return { error: 'quote_unavailable', status: lastStatus || 502 };
}

async function stockLookup(request) {
  const url = new URL(request.url);
  const market = url.searchParams.get('market');
  const code = String(url.searchParams.get('code') || '').trim().toUpperCase().replace(/\.T$/i, '');
  const symbol = normalizeSymbol(market, code);
  if (!symbol) return json({ ok: false, error: 'invalid_code' }, 400);

  const y = await fetchYahoo(symbol);
  if (!y.meta) return json({ ok: false, error: y.error || 'not_found' }, 502);

  const meta = y.meta;
  const price = y.price;
  const prev = Number(meta?.chartPreviousClose ?? meta?.previousClose);
  const changePct = Number.isFinite(prev) && prev > 0 ? (price / prev - 1) * 100 : 0;

  return json({
    ok: true,
    market,
    code,
    symbol: meta.symbol || symbol,
    name: meta.longName || meta.shortName || meta.symbol || code,
    price,
    change_pct: Math.round(changePct * 100) / 100,
    currency: meta.currency || (market === 'japan' ? 'JPY' : 'USD'),
    exchange: meta.fullExchangeName || meta.exchangeName || '',
    time: meta.regularMarketTime || null,
    source: 'yahoo'
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/stock') return stockLookup(request);
    return env.ASSETS.fetch(request);
  },
};
