const UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store, no-cache, must-revalidate, max-age=0",
      "access-control-allow-origin": "*"
    }
  });
}

function cleanCode(code) {
  return String(code || "").trim().toUpperCase().replace(/\.T$/i, "");
}

function normalizeSymbol(market, code) {
  const c = cleanCode(code);
  if (!c) return null;

  if (market === "japan") {
    if (!/^\d{4}[A-Z]?$/.test(c)) return null;
    return c + ".T";
  }

  if (market === "usa") {
    if (!/^[A-Z0-9.\-^=]+$/.test(c)) return null;
    return c;
  }

  return null;
}

function formatJST(ts) {
  if (!ts) return "";
  try {
    return new Intl.DateTimeFormat("ja-JP", {
      timeZone: "Asia/Tokyo",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
    }).format(new Date(ts * 1000));
  } catch {
    return "";
  }
}

function lastFinite(arr) {
  for (let i = (arr || []).length - 1; i >= 0; i--) {
    const n = Number(arr[i]);
    if (Number.isFinite(n)) return { value: n, index: i };
  }
  return null;
}

async function yahooChart(symbol) {
  const hosts = [
    "query1.finance.yahoo.com",
    "query2.finance.yahoo.com"
  ];

  let lastError = "";

  for (const host of hosts) {
    try {
      const url =
        `https://${host}/v8/finance/chart/${encodeURIComponent(symbol)}` +
        `?range=5d&interval=1m&includePrePost=false&events=div%2Csplits&_=${Date.now()}`;

      const r = await fetch(url, {
        headers: {
          "accept": "application/json",
          "user-agent": UA
        },
        cf: {
          cacheTtl: 0,
          cacheEverything: false
        }
      });

      if (!r.ok) {
        lastError = `${host}:${r.status}`;
        continue;
      }

      const body = await r.json();
      const result = body?.chart?.result?.[0];
      const meta = result?.meta || {};

      const closes = result?.indicators?.quote?.[0]?.close || [];
      const latest = lastFinite(closes);

      let price = latest?.value;
      let ts = latest ? Number(result?.timestamp?.[latest.index]) : Number(meta?.regularMarketTime);

      if (!Number.isFinite(price)) {
        price = Number(meta?.regularMarketPrice);
        ts = Number(meta?.regularMarketTime);
      }

      if (!Number.isFinite(price)) {
        lastError = `${host}:no_price`;
        continue;
      }

      const prev = Number(meta?.chartPreviousClose ?? meta?.previousClose);
      const changePct =
        Number.isFinite(prev) && prev > 0
          ? (price / prev - 1) * 100
          : 0;

      return {
        ok: true,
        name: meta?.longName || meta?.shortName || meta?.symbol || symbol,
        price,
        previous_close: Number.isFinite(prev) ? prev : null,
        change_pct: Math.round(changePct * 100) / 100,
        quote_time: formatJST(ts),
        source: `Yahoo chart 1m (${host === "query1.finance.yahoo.com" ? "Q1" : "Q2"})`
      };
    } catch (e) {
      lastError = String(e);
    }
  }

  return { ok: false, error: lastError || "chart_failed" };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/stock") {
      const market = String(url.searchParams.get("market") || "").toLowerCase();
      const code = cleanCode(url.searchParams.get("code"));
      const symbol = normalizeSymbol(market, code);

      if (!symbol) {
        return json({ ok: false, error: "invalid_code" }, 400);
      }

      const q = await yahooChart(symbol);

      if (!q.ok) {
        return json(
          {
            ok: false,
            error: "quote_unavailable",
            detail: q.error || ""
          },
          502
        );
      }

      return json({
        ok: true,
        market,
        code,
        symbol,
        name: q.name,
        price: q.price,
        previous_close: q.previous_close,
        change_pct: q.change_pct,
        quote_time: q.quote_time,
        source: q.source
      });
    }

    return env.ASSETS.fetch(request);
  }
};
